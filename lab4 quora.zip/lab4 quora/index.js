function resetmap(){
  google.maps.event.trigger(map, 'resize');
}
var map, infoWindow, pos, geocoder, markerMain;
function initMap() {
  map = new google.maps.Map(document.getElementById('googleMap'), {
    center: {lat: -34.397, lng: 150.644},
    zoom: 17,
    mapTypeId: 'satellite'
  });
  geocoder = new google.maps.Geocoder();
  document.getElementById('submit').addEventListener('click', function() {
    geocodeAddress(geocoder, map);
    google.maps.event.trigger(map, 'resize');
  });
  infoWindow = new google.maps.InfoWindow;
  // Try HTML5 geolocation.
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      pos = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      placeMarkerAndPanTo(pos, map);
    }, function() {
      handleLocationError(true, infoWindow, map.getCenter());
    });
  } else {
    // Browser doesn't support Geolocation
    handleLocationError(false, infoWindow, map.getCenter());
  }
  map.addListener('click', function(e) {
    placeMarkerAndPanTo(e.latLng, map);
  });
}
function placeMarkerAndPanTo(latLng, map) {
  if(markerMain!=null)
    markerMain.setMap(null);
  var marker = new google.maps.Marker({
    position: latLng,
    map: map
  });
  markerMain = marker;
  map.panTo(latLng);
  geocoder.geocode({'location': latLng}, function(results, status) {
    document.getElementById("location").innerHTML = (results[0].formatted_address);
    if (status === 'OK') {
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}
function geocodeAddress(geocoder, resultsMap) {
  markerMain.setMap(null);
  var address = document.getElementById('address').value;
  geocoder.geocode({'address': address}, function(results, status) {
    alert(results[0].formatted_address);
    if (status === 'OK') {
      resultsMap.setCenter(results[0].geometry.location);
      var marker = new google.maps.Marker({
        map: resultsMap,
        position: results[0].geometry.location
      });
      markerMain = marker;
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}
function handleLocationError(browserHasGeolocation, infoWindow, pos) {
  infoWindow.setPosition(pos);
  infoWindow.setContent(browserHasGeolocation ?
                        'Error: The Geolocation service failed.' :
                        'Error: Your browser doesn\'t support geolocation.');
  infoWindow.open(map);
}
